export interface Restaurant {
  name: string,
  image_url: string,
  price: number,
  address: string,
  city: string,
  area: string,
  country: string,
  phone: string,
  id?: number
}
