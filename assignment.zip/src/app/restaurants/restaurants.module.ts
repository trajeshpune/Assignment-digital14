import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { RestaurantsRoutingModule } from './restaurants-routing.module';

import { RestaurantsComponent } from './restaurants.component';
import { SearchComponent } from '../components/search/search.component';


@NgModule({
  declarations: [
    SearchComponent,
    RestaurantsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RestaurantsRoutingModule
  ]
})
export class RestaurantsModule { }
