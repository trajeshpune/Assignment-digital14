import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { Store, select } from '@ngrx/store';

import { AppState } from 'src/app/app.state';

import { Restaurant } from 'src/app/restaurants/models/restaurant.model';

import * as fromSelectors from 'src/app/selectors/restaurant.selectors';
import { LoadRestaurant, AddFavourite } from 'src/app/actions/restaurant.action';

@Component({
  selector: 'app-restaurants',
  templateUrl: './restaurants.component.html',
  styleUrls: ['./restaurants.component.scss']
})
export class RestaurantsComponent implements OnInit, OnDestroy
{
  restaurants$: Observable<Array<Restaurant>>;
  loading$: Observable<boolean>;
  error$: Observable<Error>;
  
  private _eventSub: Subscription;
  constructor(
    private _store: Store<AppState>
  ) { 
    this.restaurants$ = this._store.pipe(select(fromSelectors.getRestaurants));
  }

  ngOnInit() {
    this.restaurants$ = this._store.pipe(select(fromSelectors.getLoadRestaurants));
    this.loading$ = this._store.select(store => store.restaurant.loading);
    this.error$ = this._store.select(store => store.restaurant.error);
    this._store.dispatch(new LoadRestaurant());
  }
 
  addRestaurant(restaurant: Restaurant) {
    this._store.dispatch(new AddFavourite(restaurant));
  }

  ngOnDestroy() {
    this._eventSub && this._eventSub.unsubscribe();
  }
}