import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse} from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Restaurant } from '../models/restaurant.model';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(
    private _http: HttpClient
  ) { }
  
  getRestaurants$() {
    return this._http
    .get<Restaurant[]>(`${environment.apiURL}restaurants?city=all&per_page=100`)
    .pipe(
      catchError((error) => this._handleError(error))
    );
  }

  private _handleError(err: HttpErrorResponse | any) {
    const errorMsg = err.message || 'Error: Unable to complete request.';
    return throwError(errorMsg);
  }
}
