import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

import { environment } from 'src/environments/environment';
import { Restaurant } from '../models/restaurant.model';

@Injectable({
    providedIn: 'root'
})
export class SearchService
{
    constructor(
        private _http: HttpClient
    ) { }

    search$(terms: string): Observable<Restaurant[]> {
        var terms = terms || 'all';
        return this._http
        .get<Restaurant[]>(`${environment.apiURL}restaurants?city=${terms}&per_page=100`)
        .pipe(
            catchError((error) => this._handleError(error))
        );
    }

    private _handleError(err: HttpErrorResponse | any) {
        const errorMsg = err.message || 'Error: Unable to complete request.';
        return throwError(errorMsg);
    }
}