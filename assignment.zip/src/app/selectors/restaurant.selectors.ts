import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromReducers from 'src/app/reducers/restaurant.reducer';

export const getRestaurantStore = createFeatureSelector('restaurant');

export const getRestaurantEntities = createSelector(
    getRestaurantStore,
    fromReducers.restaurantEntitySelectors.selectAll
);

export const getRestaurants = createSelector(getRestaurantEntities, entities => {
    return Object.values(entities);
});

export const getLoadRestaurants = createSelector(
    getRestaurantStore,
    (store: fromReducers.RestaurantState) => store.restaurantList
);

export const getSearchRestaurants = createSelector(
    getRestaurantStore,
    (store: fromReducers.RestaurantState) => store.restaurantList
);

export const getRestaurantLoading = createSelector(
    getRestaurantStore,
    (store: fromReducers.RestaurantState) => store.loading
);

export const getRestaurantError = createSelector(
    getRestaurantStore,
    (store: fromReducers.RestaurantState) => store.error
);