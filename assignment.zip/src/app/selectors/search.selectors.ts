import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromReducers from 'src/app/reducers/search.reducer';

export const getSearchStore = createFeatureSelector('search');

export const getSearch = createSelector(
  getSearchStore,
  (store: fromReducers.SearchState) => store.search
);
