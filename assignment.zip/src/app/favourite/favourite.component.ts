import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';

import { AppState } from 'src/app/app.state';
import { Restaurant } from 'src/app/restaurants/models/restaurant.model';
import { RemoveFavourite } from 'src/app/actions/restaurant.action';

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.scss']
})
export class FavouriteComponent implements OnInit
{
  resturantsList: Observable<Restaurant[]>;

  loading: boolean;
  error: boolean;
  status: any;

  constructor(
    private _store: Store<AppState>
  ) {}

  ngOnInit() {
    this.resturantsList = this._store.select(store => store.restaurant.favouriteList);
  }

  removeFavourite(restaurant: Restaurant) {
    this._store.dispatch(new RemoveFavourite(restaurant));
  }
}
