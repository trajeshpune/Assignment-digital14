import { Component, OnInit, ChangeDetectionStrategy, OnDestroy } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';

import { AppState } from 'src/app/app.state';
import { SearchReset, Search } from 'src/app/actions/search.action';
import * as fromSearchSelectors from 'src/app/selectors/search.selectors';
import * as fromRestaurantSelectors from 'src/app/selectors/restaurant.selectors';
import { Restaurant } from 'src/app/restaurants/models/restaurant.model';
import { LoadSearchRefine } from 'src/app/actions/restaurant.action';

@Component({
    selector: 'app-search',
    templateUrl: './search.component.html',
    styleUrls: ['./search.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchComponent implements OnInit, OnDestroy
{
    restaurants$: Observable<Array<Restaurant>>;
    searchTerm$: Observable<string>;
    constructor(
        private _store: Store<AppState>
    ) { }

    ngOnInit(): void {
        this.searchTerm$ = this._store.pipe(select(fromSearchSelectors.getSearch));
        this.restaurants$ = this._store.pipe(select(fromRestaurantSelectors.getSearchRestaurants));
    }

    ngOnDestroy(): void {
        this._store.dispatch(new SearchReset());
    }

    search(terms: string): void {
        this._store.dispatch(new Search(terms));
    }

    refine(terms: string): void {
        this._store.dispatch(new LoadSearchRefine(terms));
    }
}