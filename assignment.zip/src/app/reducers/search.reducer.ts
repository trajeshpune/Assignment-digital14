import { SearchActionTypes, SearchActions } from 'src/app/actions/search.action';

export interface SearchState {
  search: string;
}

export const initialState: SearchState = {
  search: ''
};

export function reducer(state = initialState, action: SearchActions): SearchState {
  switch (action.type) {
    case SearchActionTypes.Search:
      return {
        ...state,
        search: action.payload
      };
    case SearchActionTypes.SearchReset:
      return {
        ...state,
        search: ''
      };
    default:
      return state;
  }
}
