import { EntityAdapter, createEntityAdapter, EntityState } from '@ngrx/entity';
import { RestaurantActionTypes, Actions } from 'src/app/actions/restaurant.action';
import { Restaurant } from 'src/app/restaurants/models/restaurant.model';

export interface RestaurantState  extends EntityState<Restaurant>  {
    searchTerm: string,
    originalList: Restaurant[],
    restaurantList: Restaurant[],
    favouriteList: Restaurant[],
    loading: boolean,
    error: Error
}

export const adapter: EntityAdapter<Restaurant> = createEntityAdapter<Restaurant>();

const initialState: RestaurantState = adapter.getInitialState({
    searchTerm: '',
    originalList: [],
    restaurantList: [],
    favouriteList: [],
    loading: false,
    error: undefined
});

export function reducer(state: RestaurantState = initialState, action: Actions) {
    switch(action.type) {
        case RestaurantActionTypes.LOAD_RESTAURANT: 
            return {
                ...state,
                loading: true
            }
        case RestaurantActionTypes.LOAD_RESTAURANT_SUCCESS:
            return {
                ...state,
                originalList: action.payload,
                restaurantList: action.payload,
                loading: false
            };
        case RestaurantActionTypes.LOAD_RESTAURANT_FAILURE:
            return {
                ...state,
                error: action.payload,
                loading: false
            };
        case RestaurantActionTypes.LOAD_SEARCH:
            return {
                ...state,
                loading: true
            };
        case RestaurantActionTypes.LOAD_SEARCH_REFINE:
            return {
                ...state,
                restaurantList: state.originalList.filter(item =>(item.name.toLowerCase()).search(action.payload.toLowerCase()) > -1),
                loading: false
            };
        case RestaurantActionTypes.LOAD_SEARCH_SUCCESS:
            return {
                ...state,
                originalList: action.payload,
                restaurantList: action.payload,
                loading: false
            };
        case RestaurantActionTypes.LOAD_SEARCH_RESET:
            return {
                ...state,
                restaurantList: []
            };
        case RestaurantActionTypes.ADD_FAVOURITE:
            return {
                ...state,
                favouriteList: [...state.favouriteList.filter(item => item.id !== action.payload.id), action.payload],
                loading: false
            };
        case RestaurantActionTypes.REMOVE_FAVOURITE:
            return {
                ...state,
                favouriteList: state.favouriteList.filter(item => item.id !== action.payload.id),
                loading: false
            };
        default:
            return state;
    }
}

export const restaurantEntitySelectors = adapter.getSelectors();