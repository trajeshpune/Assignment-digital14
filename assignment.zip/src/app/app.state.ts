import { SearchState } from './reducers/search.reducer';
import { RestaurantState } from './reducers/restaurant.reducer';

export interface AppState {
    readonly search: SearchState;
    readonly restaurant: RestaurantState;
}
