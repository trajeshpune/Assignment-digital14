import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { LoadRestaurantFailure, LoadRestaurantSuccess, LoadSearchSuccess, LoadSearch, RestaurantActionTypes, LoadSearchRefine } from '../actions/restaurant.action';

import { SearchService } from '../restaurants/services/search.service';
import { RestaurantService } from '../restaurants/services/restaurant.service';

@Injectable()
export class RestaurantEffects
{
    constructor(
        private _actions$: Actions,
        private _search: SearchService,
        private _service: RestaurantService
    ) {}
 
    @Effect() loadRestaurant$ = this._actions$.pipe(
        ofType(RestaurantActionTypes.LOAD_RESTAURANT),
        switchMap(() => this._service
            .getRestaurants$()
            .pipe(
                map(data => new LoadRestaurantSuccess(data['restaurants'])),
                catchError(error => of(new LoadRestaurantFailure(error)))
            )
        )
    )

    @Effect() searchRestaurant$ = this._actions$.pipe(
        ofType(RestaurantActionTypes.LOAD_SEARCH),
        switchMap(
            (action: LoadSearch) => this._search.search$(action.payload)
            .pipe(
                map(data => new LoadSearchSuccess(data['restaurants'])),
                catchError(error => of(new LoadRestaurantFailure(error)))
            )
        )
    )
}