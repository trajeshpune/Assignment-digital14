import { Injectable } from '@angular/core';
import { map, debounceTime } from 'rxjs/operators';
import { Actions, Effect, ofType } from '@ngrx/effects';

import { SearchActionTypes, Search } from 'src/app/actions/search.action';
import { LoadSearch, LoadSearchReset } from '../actions/restaurant.action';

@Injectable()
export class SearchEffects 
{
  constructor(
    private actions$: Actions
  ) {}

  @Effect()
  search$ = this.actions$.pipe(
    ofType(SearchActionTypes.Search),
    debounceTime(300),
    map((action: Search) => new LoadSearch(action.payload))
  );

  @Effect()
  reset$ = this.actions$.pipe(
    ofType(SearchActionTypes.SearchReset),
    debounceTime(300),
    map(() => new LoadSearchReset)
  );
}